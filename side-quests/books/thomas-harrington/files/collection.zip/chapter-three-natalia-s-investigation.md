# Chapter three — Natalia’s investigation

The dimly lit newsroom buzzed with a low hum of anxiety and determination. Amidst the chaos, Natalia Ivanova sat firmly at her desk, sifting through stacks of papers and photographs, her eyes narrowing as she scrutinized each detail. As an enigmatic journalist who had made quite a name for herself with her incisive reporting on the war in Ukraine, Natalia felt a deep-rooted love for her country and an unyielding sense of justice. Her dark hair was pulled back into a tight bun, strays escaping to frame her sharp features. Her fingers danced over the keyboard, instinctively crafting sentences that would soon expose the hidden truths she sought.

"Another day, another tragedy," Natalia muttered to herself, her voice a mix of exhaustion and determination. She glanced up briefly at the wall opposite her, where a map of Ukraine hung, dotted with red pins marking the locations of recent conflict zones. This war had taken a heavy toll on her people, and Natalia couldn't help but feel the weight of their suffering on her shoulders.

The sound of a colleague's voice disrupted Natalia's thoughts, shouting her name from across the room. "Hey, Natalia! Have you found any clues in your investigation yet?"

"Maybe," replied Natalia, her voice tinged with cautious optimism. "I'm following a trail of breadcrumbs that might lead somewhere interesting."

Her colleague nodded, understanding the need for secrecy. They exchanged a knowing smile before he returned to his work.

As Natalia continued her research, her mind raced with thoughts of the everyday people caught amid the complexities of this brutal conflict. Images of displaced families, wounded soldiers, and destroyed homes filled her thoughts as she worked tirelessly to reveal the truth behind the violence. It wasn't just about uncovering the facts; it was also about giving a voice to those who were often silenced by the horrors of war.

"Enough!" Natalia exclaimed suddenly, her voice barely audible amidst the cacophony of the newsroom. She closed her eyes and took a deep breath, trying to steady herself. "I need to find the truth, for them," she whispered, opening her eyes and staring at the map once more.

"Is everything all right?" asked her colleague, concern etched on his face.

"Nothing I can't handle," Natalia replied with a wry smile, masking her internal turmoil. "Just another day in paradise, right?"

He chuckled and returned to his work, leaving Natalia alone with her thoughts. As she dove back into her investigation, she couldn't help but feel an even greater sense of urgency. For her, this wasn't just a story; it was a personal mission, fueled by her love for her country and the people who called it home.

"Justice will be served," Natalia whispered, her fingers flying across the keyboard. "And I will be the one to serve it."

3 - 4

In Thomas's home, Natalia worked diligently in what resembled a war room. Her eyes and fingers moved quickly around multiple computer screens as she searched for data, cross-referenced sources, and crafted a mental image of the devastating human cost of the conflict: ruined families, changed lives, and communities struggling to mend amid the havoc.

"Thomas!" she called out, not looking up from her work. "What do you make of this?"

Thomas Harrington stood behind her, arms folded, his brow furrowed in concentration. He leaned over her shoulder, studying the screen. "It looks like we're getting closer to understanding the full scope of the situation," he said, his voice tinged with a mixture of admiration and concern.

"Indeed," Natalia agreed, her gaze never leaving the screen. "But to truly understand, we must experience it firsthand."

"Isn't that risky?" interjected Marie Duval, who had silently entered the room. She raised an eyebrow at the pair, her posture commanding respect.

"Sometimes risks must be taken," Natalia responded without hesitation, her steely determination evident. "To know the local perspective, we need to walk their streets, listen to their stories."

"Then we shall accompany you," Thomas announced, much to Marie's surprise. "Your knowledge is invaluable, and together, we can uncover the truth."

"Very well," Marie acquiesced after a moment of silence, her expression unreadable. "We'll combine our expertise and resources. But we must proceed with caution."

"Agreed," Natalia nodded, closing her laptop with a sense of finality. Her eyes met Thomas's, revealing a quiet gratitude for his support.

As they prepared to embark on their joint mission, Natalia couldn't help but reflect on the unlikely partnership that had formed between them. Each brought unique skills and perspectives to the table, and together, they were a force to be reckoned with.

Their destination was Donetsk, a regional capital that had become the site of much of the fighting in Ukraine. It was here, they were told, that there was an informant with vital information about the conspiracy. It promised to be an arduous journey, but they were determined to succeed in their mission and uncover the truth. 

"Are you ready?" Thomas asked, his voice breaking through her thoughts.

"More than ever," Natalia replied, determination shining in her eyes. "Let's uncover the truth – for them, for us, and for our countries."

As they stepped outside into the cool evening air, a sense of danger and urgency hung in the atmosphere. They knew the challenges that lay ahead – testing their mettle, challenging their notions of trust, and confronting the shadows of their pasts. But together, they were united by a common goal: to bring justice to those who had suffered in the shadows of war.

"Let's go," Natalia whispered, her breath visible in the frosty air as she led the way. And with that, they embarked on a treacherous journey – one that would forever intertwine their fates and the fate of a nation.

The trio set off early morning, travelling by car to Donetsk. The journey would take the entire day and as they travelled, Natalia felt a strange mix of excitement and dread at what awaited them there. She knew this could be a dangerous mission; her life—and those of her colleagues—were on the line. But if she succeeded in finding out what was truly going on behind closed doors, then perhaps she could make a difference for those suffering at the hands of conflict. With this thought firmly in mind, Natalia prepared herself mentally for whatever lay ahead as they continued towards their destination: Donetsk.

5 - 6

When they finaly arrived at Donetsk the sun dipped below the horizon, casting an eerie glow on the war-torn landscape as Natalia surveyed the wreckage before her. She adjusted her scarf, feeling the weight of the stories untold by the abandoned buildings and shattered glass. Her fingers itched to document every detail, to give voice to the silenced.

She turned to see the towering figure of Thomas. Speaking in a quiet and serious tone, she said, “Thomas, if we want answers, we need to talk to real people, not just documents and informants. Let’s go find some locals who can give us the scoop on what's going on here."

He nodded in agreement, his eyes darting around the area with a look of fear and resolve. "We don't have much time though," he said, looking questioningly at her. "Are you positive?"

"Absolutely," Natalia replied, her voice unwavering. "My instincts have never failed me." And with that, she strode forward, her gaze locked on the nearest figure – an elderly woman tending to her meagre vegetable patch amidst the rubble.

"Excuse me," Natalia began, her tone warm yet authoritative. "My name is Natalia Ivanova, and I'm a journalist. I want to know your story – how you've been affected by this conflict."

The woman eyed her warily, then glanced at Thomas. "Why should I speak with you?"

"Because I am Ukrainian," Natalia responded, her chest swelling with pride. "I understand what you're going through, and I want to help expose the truth – for our country and for our people."

The woman's expression softened, and she invited them to sit beside her on a makeshift bench. As they listened intently, Natalia scribbled notes in her well-worn notebook, her pen flying across the page as if trying to keep pace with the weight of each word.

"Thank you," Natalia said when the woman finished her tale, her heart heavy with sorrow but burning with resolve. "Your story will not go unheard."

As they walked away, Thomas marvelled at her ability to coax the truth from even the most reticent of witnesses. "Your journalistic background really shines through," he said, admiration colouring his voice. "How did you get into this line of work?"

"Ever since I was a child, I've been fascinated by the power of words – their ability to shape reality and unveil hidden truths," Natalia explained, her eyes alight with passion. "But it wasn't until the war broke out that I realized my true calling: to use my talents to fight for justice and protect my beloved Ukraine."

"Your patriotism is inspiring," Thomas admitted, his expression solemn. "And your understanding of this war's complexities is invaluable to our mission."

"Thank you, Thomas," she replied, her cheeks flushed with pride. "Together, we'll expose the truth and bring those responsible to justice – no matter the cost."

As they continued their investigation, Natalia's fervent sense of purpose drove them forward, each step closer to unravelling the tangled web of conspiracy that threatened her homeland. And as the sun finally set on another day of turmoil, one thing was certain: Natalia Ivanova would not rest until the truth was revealed and her country was safe once more.

---

As Natalia and Thomas stood beneath the skeletal branches of a snow-laden tree, their breaths hung in the crisp air like whispered secrets. The setting sun cast long shadows across the desolate street, reflecting the myriad complexities that lay hidden beneath the surface of their shared mission.

"Natalia," Thomas began, his voice sombre, "I don't need to tell you how important our mission is. Our fates, and the fate of Ukraine, are intertwined." He paused, his gaze steady upon her. "We must be prepared for the dangers we face."

"I understand, Thomas," Natalia replied, her eyes clouded with the weight of responsibility. "I came here as a journalist, but I'm ready to stand by your side and face whatever comes our way."

"Good," he said, nodding. "We'll need each other's strength and resolve to see this through."

As they walked on, Natalia couldn't help but notice the subtle hints of Thomas's internal struggle: the furrow in his brow, the almost imperceptible clenching of his fists. It was comforting, in a way, to know that he too grappled with the enormity of their task.

"Thomas," she ventured carefully, "do you ever doubt yourself?"

He sighed, rubbing the back of his neck. "I'd be lying if I said I didn't. But every time I think about the people we're fighting for, it strengthens my resolve."

"Same for me," Natalia agreed, her heart swelling with admiration for him. "But remember, we have each other – and together, we are stronger."

"Indeed," Thomas said, offering her a small, reassuring smile. "It's good to know we share the same determination."

Their conversation turned to the minutiae of their investigation – names, dates, and potential leads – but it was underscored by the unspoken understanding that they were bound together by something much larger than themselves. The fate of a nation, and their own lives, hung in the balance.

As they kept headed forward a nondescript building that housed one of their key informants on the other side of town, Natalia felt a shiver of apprehension snake its way down her spine. This was not just another interview; it was another step into the heart of darkness, another test of their mettle and commitment to the truth.

"Ready?" Thomas asked his hand on the door handle.

"Always," Natalia replied, steeling herself for the unknown that awaited them.

With that, they stepped inside, each silently vowing to face the challenges ahead with unwavering resolve, knowing that only together could they succeed in untangling the perilous web of conspiracy that threatened to engulf their world.

9 - 10

The sun had barely risen, casting long shadows across the desolate landscape as Natalia and Thomas set out on their treacherous journey. The wind whistled through the bullet-ridden buildings, a chilling reminder of the dangers that lurked around every corner. Natalia pulled her scarf tighter around her neck, trying to keep the biting cold at bay.

"Remember," Thomas said, his breath creating puffs of white vapor in the freezing air, "we only have one shot at this. If we miss our window, it could be game over for us – and for Ukraine."

Natalia nodded, her eyes scanning the horizon for any signs of trouble. She knew he was right; the stakes were higher than ever, and the chances of success slim. But she couldn't afford to dwell on the odds, not when so much depended on their actions.

As they trudged onward, the weight of their mission bore down on them, making every step feel like a battle against gravity itself. Tensions flared as they navigated the treacherous terrain, their shared goal the only thing keeping them moving forward.

"Watch your step," Thomas warned as Natalia's foot slipped on a pice of broken floor. "We can't afford any injuries."

"Trust me, I'm well aware," she snapped back, her frustration bubbling to the surface. "I've been navigating these streets my whole life."

"Sorry," Thomas muttered, realizing he'd overstepped. "I just... I worry about you, that's all."

Natalia softened, understanding the sentiment behind his words. "I know. And I worry about you too. We need each other now more than ever."

Their journey continued, fraught with perilous obstacles: hidden landmines, snipers lurking in the shadows, and the constant threat of betrayal by people they thought they could trust. With each challenge they faced, their bond grew stronger, but so too did the ghosts of their pasts.

"Thomas," Natalia said during a brief respite, her voice barely audible over the howling wind. "Have you ever thought about what will happen if... if we don't make it out of this alive?"

"Of course I have," he admitted, his eyes haunted by the weight of all the lives he'd seen snuffed out in the line of duty. "But that's why we have to keep going – because the alternative is unthinkable."

Natalia nodded, her thoughts drifting to the faces of those she'd lost to the conflict, their memories urging her forward with renewed determination. As they pressed on, the shadows of their pasts loomed ever larger, threatening to consume them entirely.

"Stay vigilant," Thomas whispered as they neared their destination, the adrenaline coursing through their veins making every sense heightened. "We're almost there."

"Then let's finish this," Natalia replied, her voice steely with resolve. Together, they faced the final leg of their journey head-on, knowing that only by confronting the darkness could they hope to bring light to their war-ravaged country.

11 - 11

The air was thick with tension as Thomas and Natalia stepped out of the shadows, their breaths visible in the icy night. Snow crunched under their boots as they surveyed the darkened expanse that lay before them – a treacherous landscape fraught with danger and hidden threats.

"Are you ready?" Thomas asked his voice tight with anticipation.

Natalia glanced at him, her eyes alight with determination. "I've been ready since the moment we started this," she replied, her accent making the words sound both exotic and fierce.

They moved forward cautiously, each step carefully measured to avoid drawing attention to themselves. As they navigated the frozen terrain, Thomas couldn't help but be struck by the stark beauty of the Ukrainian countryside, its vastness dwarfed only by the gravity of their mission.

"Thomas," Natalia murmured, her expression pained as she looked back at the distant glow of city lights. "We must remember why we're doing this – for our people, for our countries."

"Of course," he agreed, his thoughts drifting to the countless lives that had been upended by the conflict, each one a reminder of the stakes they were playing for.

Their progress was slow, hindered by the biting cold and the ever-present threat of discovery. But with each passing minute, the urgency of their task seemed to grow, fueling their resolve to see it through to the end.

"Wait," Thomas whispered suddenly, his instincts flaring as he sensed movement in the darkness ahead. He reached for Natalia's arm, pulling her down behind a snow-covered boulder just as a figure emerged from the shadows.

"Who is it?" Natalia asked, keeping her voice low as they watched the stranger approach their position.

"Can't be sure," Thomas answered, his hand inching towards his concealed weapon. "But we can't afford to take any chances."

As the figure drew nearer, Thomas felt the weight of their mission bearing down on him, the lives of those they sought to protect hanging in the balance. They had come too far to fail now, and yet the dangers that lay ahead were like a churning sea of uncertainty, each wave threatening to drag them under.

"Stay close," he told Natalia, his voice barely more than a breath. "Whatever happens, we face it together."

Natalia nodded, her gaze never leaving the approaching figure. "Together," she echoed, her voice tinged with a steely resolve that sent a shiver down Thomas's spine.

As the figure loomed closer, Thomas knew that the moment had finally arrived – the first in a series of confrontations that would test their mettle, challenge their trust, and force them to navigate a perilous web of conspiracy and lies. But it was a path they had chosen willingly, driven by an unyielding sense of justice and a desire to uncover the truth.

"Ready?" he asked, glancing at Natalia one last time.

"Always," she answered, her eyes blazing with determination.

And with that, they stepped forward to meet their fate, the shadows of their pasts fading into the darkness as they embraced the unknown that lay before them.

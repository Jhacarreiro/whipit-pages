# Chapter four — the informant

1 - 2

The wind whispered through the tall grass, carrying with it the scent of damp earth as Natalia and Thomas stood on the outskirts of Kyiv. Beyond them, the city stretched out like a grey quilt, yet there was some comfort to be found in the beauty that surrounded them. The anticipation of their meeting with Dmitri Orlov, the elusive informant, pressed down upon them like an oppressive weight.

"Ready?" Natalia asked, her voice barely audible against the breeze. Her eyes were sharp and focused, betraying only a hint of the anxiety she felt deep inside.

"As ready as I'll ever be," Thomas replied, trying to maintain a sense of ease despite his own nerves. He glanced over at Natalia, noticing the way she meticulously checked her equipment, ensuring her recording devices were in working order.

Thomas took a moment to check his gun, running his fingers over the cold metal, feeling its familiar weight in his hand. His mind raced with thoughts of what they might uncover from Dmitri. Secrets that could shake the very foundations of their world.

The sun hung low in the sky, casting long shadows that seemed to mirror the secrets they were about to unearth. As the minutes ticked by, the air grew heavier, thick with unspoken tension.

"Remember," Natalia said, looking up from her equipment, "we don't know who we can trust. Even Orlov may try to deceive us."

"Trust me," Thomas said, his voice laced with bitterness, "I'm well aware of how deceptive people can be." His mind wandered back to previous missions, to allies turned enemies in the blink of an eye.

"Good," Natalia replied, her expression unreadable. "We need to be vigilant. Our lives, our countries, depend on it."

As the final preparations were made, both Natalia and Thomas came to terms with the gravity of their situation. They were two lone figures, standing against a vast backdrop of intrigue and danger. And as they waited for the arrival of Dmitri Orlov, they understood that their every word, every action, could determine not only their own fate but that of countless others.

"Let's do this," Thomas murmured, his grip tightening on his gun. The sun dipped closer to the horizon, its dying light casting an eerie glow over the landscape.

"Da," Natalia agreed, her gaze steely and determined. "Let's."

And with that, they stepped forward into the fading light, ready to face the darkness that awaited them.

3 - 4

The wind whispered through the trees, rustling leaves and carrying a chill that seemed to seep into their very bones. Natalia shivered, her breath visible in the rapidly cooling air. Thomas shifted his weight from one foot to the other, eyes scanning the shadows warily.

"Thomas," Marie's voice crackled through the radio, "Natalia, I cannot stress enough how dangerous this situation is. Dmitri Orlov is not a man to be trifled with. He will use every trick at his disposal to manipulate you."

"Understood, Marie," Thomas replied, his voice betraying none of the unease he felt. "We'll be cautious."

"Da," Natalia added, her eyes meeting Thomas's for a moment before returning to her surroundings. "We will not let our guard down."

"Good," Marie said, her tone firm but laced with concern. "Keep your wits about you and remember - trust no one."

As they moved closer to the clearing, the tension between them was palpable, each step heavy with uncertainty. The tall pines loomed overhead, branches casting eerie shapes in the fading light. Despite the beauty of the scenery, it felt more like a trap than a rendezvous point.

"Something feels off," Natalia murmured, her eyes darting back and forth. "Can you sense it?"

"Like we're walking into a lion's den," Thomas agreed his grip on his gun tightening. "But we can't turn back now."

"No," she said, determination shining in her eyes. "We've come too far to give up."

The secluded clearing revealed itself slowly, a small oasis amidst the oppressive forest. A single beam of sunlight pierced the canopy, illuminating the centre of the space like a stage. It was there they would meet Dmitri Orlov, the man who held the key to unravelling a web of deceit.

"Stay sharp, Natalia," Thomas said, his voice low. "We don't know what to expect from Orlov."

"Same applies to you, Thomas," she replied, her gaze never leaving the far edge of the clearing. "I have a feeling we'll need each other more than ever tonight."

Their footsteps grew quieter as they neared the rendezvous point, the weight of their mission settling heavily upon them. With every passing second, the danger loomed closer, threatening to consume them in its dark embrace. But together, they would face it head-on, ready to confront the shadowy figure who held the answers they sought.

5 - 6

As the last of the day's light filtered through the trees, casting intricate patterns on the forest floor, the shadows seemed to come alive. It was from this living darkness that Dmitri Orlov emerged, his presence immediate and commanding. His air of confidence betrayed no hint of fear or uncertainty, and his sharp features seemed sculpted from the very shadows that had concealed him.

"Mr Harrington, Miss Ivanova," he greeted them smoothly, his piercing gaze locking onto each in turn. "It's a pleasure to finally meet you both face-to-face."

Natalia's breath caught in her throat as she braced herself for what was sure to be intense verbal sparring. Thomas's grip on his gun tightened, his mind churning with calculations, strategies, and countermeasures.

"Orlov," Thomas managed, keeping his voice level. "We have some questions for you."

"Of course," Dmitri replied, his lips curling into a sly grin. "And I'm certain you'll find my answers... enlightening."

He paused, letting the silence stretch between them like a taut wire. The tension in the air grew palpable, charged with anticipation and veiled threats. Then, with deceptive nonchalance, Dmitri began to speak.

"Your investigation has been a thorn in my side for quite some time now," he said casually, as though discussing the weather. "But I must admit, it's been rather... amusing to watch your efforts."

Natalia clenched her fists, fighting the urge to lunge at him. How dare he mock their mission, their struggle for the truth? She knew they had to keep calm and collected, but it was easier said than done in the face of such provocation.

Thomas, sensing Natalia's anger and feeling his own mounting frustration, stepped forward, his voice steady but firm. "We're not here for your amusement, Orlov. We're here to put an end to this conspiracy and bring those responsible to justice."

"Ah, justice," Dmitri mused, his eyes narrowing. "Such a noble pursuit. But, tell me, Mr. Harrington, how do you define justice? And what of the sacrifices one must make in the name of such lofty ideals?"

It was a trap, both Natalia and Thomas knew it, but they had no choice but to engage with him, to navigate the treacherous dance of wits and words that would, hopefully, lead them closer to the truth. They exchanged a glance, their expressions resolute, as they prepared to face whatever challenges Dmitri Orlov had in store for them.

"Justice is the pursuit of truth," Thomas replied, "and the punishment of those who betray their country and its people."

"Truth, betrayal... such powerful words," Dmitri said, his voice dripping with sarcasm. "But in my experience, they are constructs, easily twisted to suit one's purposes."

"Is that how you justify your actions?" Natalia shot back, her voice cold and hard. "By twisting the truth into something you can manipulate for your own gain?"

"Perhaps," Dmitri conceded, his gaze never leaving hers. "But then again, I wouldn't be where I am today if I hadn't learned how to play the game."

As the sun dipped below the horizon, plunging the clearing into shadow, Natalia and Thomas realized that this game had only just begun.

---

Natalia noticed the way Dmitri's fingers tapped restlessly against his thigh, an almost imperceptible rhythm that betrayed a hidden agitation. She decided to test the waters, her voice steady and even. "Mr Orlov, we're not interested in playing games. We need your help to uncover the truth."

"Ah, but what is the truth?" Dmitri countered, his lips curling into a sardonic smile. "Is it not subjective, depending on one's perspective?"

"Truth is like a diamond," she replied, her eyes never leaving his. "It may have many facets, but ultimately, its core remains unchanging."

He leaned back, clearly considering her words. Meanwhile, Thomas observed the subtle shift in Dmitri's stance, the way his shoulders tensed when Natalia spoke of truth. It was as if he were trying to hide something vulnerable beneath layers of bravado.

"Very poetic," Dmitri said finally, his tone dripping with disdain. "But perhaps you are both naïve in thinking that the truth can be so easily grasped."

"Perhaps," Thomas conceded, hoping to draw out more information. "But we're willing to try."

"Then by all means," Dmitri gestured expansively, "ask your questions. I'll do my best to entertain."

Natalia's mind raced, weighing each potential question before settling on one she hoped would pierce through Dmitri's carefully crafted facade. "Tell us, Mr Orlov, why did you agree to this meeting? What do you hope to gain from helping us?"

Dmitri's eyes narrowed, and for a moment, Thomas thought he detected a flicker of uncertainty. "I'm merely a businessman," he replied smoothly. "And like any good businessman, I understand the value of making... strategic alliances."

"Or perhaps you're simply hedging your bets," Natalia suggested, her gaze unwavering. "A way to ensure your own survival, regardless of who comes out on top."

"Survival is the name of the game, my dear," Dmitri replied with a chuckle. "But enough about me. What about you? What drives you both in this desperate search for the truth?"

"Justice," Thomas answered without hesitation, his resolve strengthening as he recognized the opening Natalia had created.

"Ah, justice," Dmitri mused, his eyes flicking between them. "A noble pursuit, but one fraught with danger, don't you think?"

"Perhaps," Natalia allowed, her voice softening ever so slightly. "But it's a risk we're willing to take."

"Very well," Dmitri said, his expression unreadable. "I suppose I'll have to content myself with watching the ensuing drama unfold."

As the conversation continued, Natalia and Thomas pressed forward, their determination unwavering. They knew they were playing a dangerous game with Dmitri Orlov, but it was a game they couldn't afford to lose. With each carefully chosen word, every subtle observation, they sought to expose the web of deception that surrounded him, inching ever closer to the truth they sought.

9 - 10

Dmitri leaned forward, his eyes gleaming with a predatory glint. "You know, Natalia, it's not often I encounter someone as tenacious as you. It's almost... refreshing." His voice was low and measured, each syllable chosen with care.

"Is that supposed to be a compliment?" Natalia countered, her tone sharp but controlled. Thomas could see the effort she put into masking her emotions, her grip on the situation precarious but unyielding. He admired her resilience.

"Take it however you like." Dmitri shrugged nonchalantly, the gesture at odds with the calculating gleam in his eyes. "But allow me to share something with you both. You're not the first to come knocking on my door, searching for answers. And you certainly won't be the last."

"Then perhaps it's time you started talking," Thomas interjected, his frustration simmering beneath the surface. He clenched his fists, fighting the urge to reach for his gun. This wasn't the time for rash decisions.

"Ah, but where would the fun be in that?" Dmitri replied, his lips curling into a twisted smile. "The thrill of the chase is what keeps life interesting, don't you think?"

"Enough games, Dmitri," Natalia snapped, her patience wearing thin. "We're here for the truth, and we won't leave until we have it."

"Very well," Dmitri conceded, leaning back in his chair. "I'll give you a small morsel to chew on. Something to whet your appetite, if you will."

Thomas felt his heart race, the anticipation building. This was their chance, an opportunity to finally crack open Dmitri's web of deceit. He exchanged a quick glance with Natalia, steeling himself for what was to come.

"Your little operation goes much deeper than you realize," Dmitri began, his voice barely above a whisper. "There are... connections you've yet to uncover. Alliances that have been formed in the shadows, waiting for the perfect moment to strike."

"Who?" Thomas demanded, his voice hoarse with urgency. "Tell us who's involved."

"Ah, but that would be giving away far too much," Dmitri chastised, wagging a finger in mock disapproval. "I've given you a starting point. The rest is up to you."

"Damn it, Dmitri," Natalia hissed, her eyes flashing with anger. "We don't have time for your games. People's lives are at stake."

"Indeed they are," Dmitri agreed, his expression sobering for a brief moment. "But this is the world we live in, my dear. One where secrets hold power and information is currency. And I, for one, am not about to give up my wealth so easily."

As he spoke, Thomas felt the tension between them coil tighter, ready to snap. The air was thick with unspoken threats and simmering emotions, each word exchanged feeling like a dagger aimed at their throats. Their senses were heightened, acutely aware of every detail, from the whispered rustle of leaves outside to the flickering shadows that danced across the room.

"Fine," Natalia said finally, her voice laced with determination. "If that's how you want to play it, then so be it. But know this, Dmitri: we won't stop until we've uncovered the truth. And when we do, there will be nowhere left for you to hide."

"Bold words, Natalia," Dmitri replied, his smile returning as he rose from his seat. "I look forward to seeing you try."

And with that, he disappeared into the shadows, leaving Natalia and Thomas to navigate the treacherous path that lay ahead.

11 - 12

Natalia's eyes locked onto Thomas's, and the silent understanding between them was as palpable as the tension that lingered in the air. The shadows seemed to close around Dmitri as he retreated, leaving the pair standing in the clearing, a mixture of determination and uncertainty etched on their faces.

"Marie will want to hear about this," Thomas said, reaching for the communication device. Marie's voice crackled to life, a welcome reminder of the guidance they had behind them.

"Report, Harrington," she instructed, her tone both stern and comforting.

"Orlov was... difficult," Thomas admitted. "He gave us some information, but it's hard to separate the truth from the lies."

"Be cautious with him," Marie warned. "Dmitri Orlov is not to be underestimated."

"Understood," Natalia interjected, eager to contribute. "But I think we're getting closer to what we need."

"Then keep pressing forward," Marie urged. "You two are our best chance at exposing this plot and bringing those responsible to justice."

"Thank you, Marie," Thomas replied. "We won't let you down."

The line went silent, and Natalia and Thomas exchanged a determined glance. There was no time to waste – they had a plan to devise, questions to answer, and a traitor to unmask.

"Thomas," Natalia began, her voice low and measured. "I believe Dmitri was trying to tell us something without saying it outright. He mentioned a meeting, but the details were vague."

"Agreed," Thomas said, rubbing his chin thoughtfully. "He's playing a dangerous game. But we can use that to our advantage. Let's go through everything he said, every gesture, every implication. There must be something he let slip that will lead us closer to the truth."

"Come on," Thomas said quietly, his voice betraying a hint of weariness. "Let's get back to the safe house."

As they retraced their steps through the dense foliage, Natalia couldn't help but replay the meeting with Dmitri in her mind. Despite his cunning and evasive tactics, she felt confident there were hidden truths buried within his words – truths that could hold the key to unlocking the conspiracy they had been chasing for months.

Upon reaching the safe house, Thomas methodically checked the perimeter before allowing Natalia to enter. She appreciated his protective instincts, even as she knew she was more than capable of handling herself.

As they settled into their makeshift war room, surrounded by maps and documents, the weight of their mission bore down upon them. They knew they were not just fighting for justice but for the very lives of those caught in the web of treachery and deceit.

With each passing moment, as they dissected Dmitri's words and actions, the stakes grew higher, and the line between truth and deception blurred further. Yet, beneath the layers of uncertainty and fear, one thing remained clear: Natalia and Thomas would stop at nothing to expose the secrets hidden in the shadows of Kyiv.

13 - 13

The sun dipped below the horizon as Natalia and Thomas exited the safe house, casting a warm glow over the rolling fields surrounding them. Their breaths formed misty clouds in the crisp air, a stark reminder of the chill that had settled into their bones.

"Where to now?" Natalia asked, her voice steady despite the uncertainty that lay ahead.

"First, we need to verify Dmitri's information," Thomas replied, already moving towards their inconspicuous vehicle parked nearby. "Then, we'll plan our next move based on what we find."

Natalia nodded, her eyes narrowing with determination. She couldn't help but feel a sense of exhilaration – they were on the cusp of uncovering something monumental, and she knew that every step they took would bring them closer to the truth.

As they climbed into the car, Thomas glanced over at Natalia, his own resolve mirrored in her expression. "We'll need to be careful," he said softly, starting the engine. "Dmitri is cunning, and I'm sure he has a few more tricks up his sleeve."

"Of course," Natalia agreed, gripping the door handle. Her mind raced with thoughts of what they might discover, the secrets that could change everything. But beneath her anticipation, a quiet fear stirred – how far would they have to go to outmanoeuvre a man like Dmitri Orlov?

The car pulled away from the safe house, its tires crunching over the gravel road as it disappeared into the fading light. The countryside swallowed them whole, embracing them in its vastness and silence. And yet, within this peaceful setting, the wheels of an intricate game continued to turn.

"Thomas," Natalia said suddenly, her gaze fixed on the darkening skies. "Do you ever wonder if we're playing into Dmitri's hands? What if all of this is just part of his plan?"

"Of course, I've considered it," Thomas admitted, his grip tightening on the steering wheel. "But, we have no choice but to keep moving forward. We can't let fear dictate our actions – not when so much is at stake."

Natalia nodded, taking a deep breath. She knew Thomas was right; they had come too far to turn back now.

And so, with their resolve unyielding and their eyes fixed on the path ahead, Natalia and Thomas pressed onward into the night. They knew that the road would be fraught with challenges and deception, but they were determined to outwit the cunning Dmitri Orlov and unveil the secrets he guarded so fiercely. Each turn of the wheel brought them closer to their goal, and with every passing mile, their determination grew stronger.
